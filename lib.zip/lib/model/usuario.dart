class Usuario {
  late final int id;
  late final String nome;
  late final String email;
  late final String senha;

  Usuario({required this.id, required this.nome, required this.email, required this.senha});
}
