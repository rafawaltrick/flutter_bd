class Produto{
  late final int id;
  late final String nome;
  late final int preco;
  late final String descricao;
  late final int quantidade;

  Produto({required this.id, required this.nome, required this.preco, required this.descricao, required this.quantidade});
}